#include <iostream>
using namespace std;
int main(){
    int N;
    double cost , discountedCost , total = 0; 
    
    cout << "Enter a number gardens:" ;
    cin>> cost;
    
    if (int i = 0 ; i < N ; i++){
        cout << "Enter service cost for garden " <<i+1 <<:;+
        cin ; cost ; 
        if (cost>4200){
            discountedCost = cost (cost - 0.09);
            
        }else {
            discountedCost = cost ; 
        }
        total+=discountedCost;
        cout << "Discounted Cost for garden " <<i+1 << ":" << discountedCost <<endl ;
        
    }
        
    cout << "Total cost of all garden : " << total << endl ;
    return  0 ;
}